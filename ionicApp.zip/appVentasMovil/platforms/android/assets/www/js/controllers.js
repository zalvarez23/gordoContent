function getHora(){
  var f=new Date();
  var hora=f.getHours()+":"+f.getMinutes()+":"+f.getSeconds(); 
  return hora;
}
function getFecha(){
  var today = new Date();
  var dd = today.getDate();
  var mm = today.getMonth()+1; //January is 0!

  var yyyy = today.getFullYear();
  if(dd<10){
      dd='0'+dd;
  } 
  if(mm<10){
      mm='0'+mm;
  } 
  var today = yyyy+'-'+mm+'-'+dd;
  return today;
}
var urlApi = "http://167.250.205.67/Controladores/";
angular.module('starter.controllers', [])

.controller('homeCtrl', function($scope,$ionicPopup,$state,$timeout){
  
  $scope.cerrarSesion = function(){
    var alertPopup = $ionicPopup.confirm({
       title: 'Confirmar..',
       template: 'Esta apunto de cerrar sesión, desea continuar ?',
       cssClass: 'checkPop',
       scope:$scope
     });
    alertPopup.then(function(res){
      if (res) {
        alertPopup.close();
        var template = "<div style='text-align:center;'>" +
                           "<ion-spinner icon='android' class='loadingok'></ion-spinner></div>";    
        var alertLoader = $ionicPopup.alert({
                    title : 'Cerrando Sesión . .',
                    template : template,
                    cssClass : 'popButtonHide',
                    scope: $scope          
        })
        $timeout(function(){
          alertLoader.close();
          $state.go('login');
        },1200)
      }
    })
  }
})
.controller('DashCtrl', function($scope,$ionicPopup,$state,$q,$http,$timeout) {
    var dataSuper = JSON.parse(localStorage.getItem('dataSuper'))[0];
    $scope.nomSuper = dataSuper.NOMBRE_PERSONA + ' ' + dataSuper.APELLIDOS_PERSONA;
    $scope.buttonSave = "Actualizar Datos";
    var sexo = dataSuper.SEXO == 'M' ? 'Masculino' : 'Femenino';
    
    $scope.dataSuper = {
      nombres : 'Nombres : ' + dataSuper.NOMBRE_PERSONA,
      apellidos : 'Apellidos : ' + dataSuper.APELLIDOS_PERSONA,
      edad : 'Edad : ' + dataSuper.EDAD,
      direccion : 'Dirección : ' + dataSuper.DIRECCION,
      sexo : 'Sexo : ' + sexo
    }
    $scope.newCheckList = function(){
      var alertPopup = $ionicPopup.confirm({
        title: 'Confirmación',
        template: 'Realizara un nuevo registro, desea continuar?',
        cssClass: '',
        scope:$scope
      });
      alertPopup.then(function(result){
        if (result) {
          $state.go('tab.dash-detail');
        }
      })
    }
    $scope.changeView = function(view){      
      $state.go(view)
    }
    $scope.disabledDataUser = "disabledContent2";
    $scope.updateDataUser = function(){
      if ($scope.buttonSave == "Guardar Datos") {
 
        var sex = $scope.dataSuper.sexo == 'Masculino' ? 'M' : 'F';
        dataSuper.APELLIDOS_PERSONA = $scope.dataSuper.apellidos;
        dataSuper.NOMBRE_PERSONA = $scope.dataSuper.nombres;
        dataSuper.EDAD = $scope.dataSuper.edad;
        dataSuper.DIRECCION = $scope.dataSuper.direccion;
        dataSuper.SEXO = sex;
        var listDataUser = [];
        listDataUser.push(dataSuper)
        localStorage.setItem('dataSuper',JSON.stringify(listDataUser));

        $scope.updateUserHttp(dataSuper).then(function(res){
          console.log(res)
        },function(){

        })

        $scope.dataSuper = {
          nombres : 'Nombres : ' + $scope.dataSuper.nombres,
          apellidos : 'Apellidos : ' + $scope.dataSuper.apellidos,
          edad : 'Edad : ' + $scope.dataSuper.edad,
          direccion : 'Dirección : ' + $scope.dataSuper.direccion,
          sexo : 'Sexo : ' + $scope.dataSuper.sexo
        }
        $scope.disabledDataUser = "disabledContent2";
        $scope.buttonSave = "Actualizar Datos";
        return;
      }else{
        $scope.disabledDataUser = "";
        $scope.buttonSave = "Guardar Datos";        
      };
      $scope.dataSuper = {
        nombres : dataSuper.NOMBRE_PERSONA,
        apellidos : dataSuper.APELLIDOS_PERSONA,
        edad : dataSuper.EDAD,
        direccion : dataSuper.DIRECCION,
        sexo :  sexo
      }      
    }
    $scope.updateUserHttp = function(dataUSer){
      var q = $q.defer();
    var url = urlApi + 'updatePersonal.php';
    
    var params = {
      nombres : dataSuper.NOMBRE_PERSONA,
      apellidos : dataUSer.APELLIDOS_PERSONA,
      edad : dataUSer.EDAD,
      sexo : dataUSer.SEXO,
      direccion : dataUSer.DIRECCION,
      idpersona : dataUSer.ID_PERSONA
    }
    $http.post(url,params,{
              headers : {
                'Content-Type' : 'application/x-www-form-urlencoded; charset=UTF-8'
            }}).success(function(result){  
   
                q.resolve(result)
            }).error(function(err){
               $ionicPopup.alert({
                  title : 'Error . .',
                  template : 'Ocurrio un problema con la conexión..'
                })
               q.reject('errr');
            })   

            return q.promise;   
    }
    $scope.getHistorial = function(){
     var url = urlApi + 'listHistorial.php';
    var params = {
      pesona : dataSuper.ID_PERSONA
    }
    
    $http.post(url,params,{
              headers : {
                'Content-Type' : 'application/x-www-form-urlencoded; charset=UTF-8'
            }}).success(function(result){
              if (result[0] == "ERROR") {
                $scope.cantidadReservas = 0;
                $scope.puntosRealizados = 0;
                return;

              };

              $scope.cantidadReservas = result.length;
              $scope.puntosRealizados = 100 * parseInt(result.length);
            }).error(function(err){
               $ionicPopup.alert({
                  title : 'Error . .',
                  template : 'Ocurrio un problema con la conexión..'
                })
            })
    }

    $scope.promosiones = [
    { id : 1 , des : 'Viaja a cusco ! y gana 1500 puntos para poder canjearlos por pasajes'},
    { id : 2 , des : 'Por cada reserva de pasaje gana 200 puntos gratis !'},
    ]
    $scope.cange = [
    { id : 1, des : 'Microondas', puntos : '1000', img : 'img/1.jpg'},
    { id : 2, des : 'Gorro de sol', puntos : '500', img : 'img/2.jpg'},
    { id : 3, des : 'Lentes de sol', puntos : '400', img : 'img/3.jpg'},
    { id : 4, des : 'Zapatillas', puntos : '1200', img : 'img/4.jpg'},
    ]
    $scope.getCange = function(){
      var cabecera = "Productos para Canjear ";
      var template = '<h3 class="title" style="text-align:justify;">El canje se podra realizar solo en nuestras instalaciones.</h3><div class="modalStyle">'+
               '<div class="list cardKevin" ng-repeat="item in cange">'+
              '<a class="item item-avatar">'+
              '<img ng-src="{{item.img}}">' +
              '<h2>{{item.des}}</h2>' +
              '<p>Cajealo por {{item.puntos}}</p></a></div></div>';
      alertPopup = $ionicPopup.alert({
        title: cabecera,
        template: template,
        cssClass: '',
        scope:$scope
      });
    }    
    $scope.getPromosiones = function(){
      var cabecera = "Promosiones vigentes";
      var template = '<div class="modalStyle">'+
               '<div class="card-panel grey lighten-5 z-depth-1 cardP" ng-repeat="item in promosiones">' +
                     '<div class="row valign-wrapper contentPlantilla">'+
                     '<div class="col s8 m10"><span class="black-text">#{{item.id}} {{item.des}}</span>' +
                     '</div></div></div></div>';
      alertPopup = $ionicPopup.alert({
        title: cabecera,
        template: template,
        cssClass: '',
        scope:$scope
      });
    }

})
.controller('DashCtrl2', function($scope,$http,$state){
    var dataSuper = JSON.parse(localStorage.getItem('dataSuper'))[0];    
    $scope.nomSuper = dataSuper.NOMBRE_PERSONA + ' ' + dataSuper.APELLIDOS_PERSONA;
    var url = urlApi + 'listCheckListAll.php';
    $http.post(url,$scope.params,{
              headers : {
                'Content-Type' : 'application/x-www-form-urlencoded; charset=UTF-8'
            }})
    .success(function(res){      
      $scope.listCheckAll = res;
    })
    .error(function(err){

    })
    $scope.newCheckList = function(item){
      localStorage.setItem('checkDetail',JSON.stringify(item));
      $state.go('tab.dash2-detail');
    }

})
.controller('checkDetailCtrl', function($scope,$ionicModal){    
    var listCheckItem = JSON.parse(localStorage.getItem('checkDetail'));
    var fechaD = document.getElementById('dtFechaD');
    fechaD.value = listCheckItem.fechaA;
    $scope.paramsCabecera = {
      hora : listCheckItem.hora,
      unidad : listCheckItem.unidad,
      supervisor : listCheckItem.nombres + ' ' + listCheckItem.apellidos,
      observacion : listCheckItem.observacion,
      ubicacion : listCheckItem.ubicacion
    }    
    $scope.listCheckList = JSON.parse(listCheckItem.regTotal);        
    $scope.getCheck= function(item){
      if (item.no) {
        return 'No'
      }else if(item.si){
        return 'Si'
      }else if(item.noapli){
        return 'No Aplica'
      }
    }
   $ionicModal.fromTemplateUrl('my-modal.html', {
    scope: $scope,
    animation: 'slide-in-up'
   }).then(function(modal) {
    $scope.modal = modal;
   });
  $scope.openModal = function() {
    console.log($scope.paramsCabecera)
    var ubi = $scope.paramsCabecera.ubicacion.split('|');
    $scope.ubicacion = {
      lat : ubi[0],
      long : ubi[1]
    }
    $scope.modal.show();
  };
  $scope.closeModal = function() {
    console.log('Close')
    $scope.modal.hide();
  };    

})
.controller('loginCtrl', function($scope,$http,$ionicPopup,$timeout,$state,$ionicModal,Chats){

Chats.go();












  $scope.showLoaderLogIn = false;
  $scope.showButtonLog = true;
  $scope.params = {
    usu : '',
    pass : ''
  }
  $scope.logIn = function(){
    var template = "<div style='text-align:center;'>" +
                       "<ion-spinner icon='android' class='loadingok'></ion-spinner></div>";    
    var alertLoader = $ionicPopup.alert({
                title : 'Iniciando Sesión . .',
                template : template,
                cssClass : 'popButtonHide',
                scope: $scope          
              })    
    var url = urlApi + 'LogIn.php';   
    console.log(url) 
    $http.post(url,$scope.params,{
              headers : {
                'Content-Type' : 'application/x-www-form-urlencoded; charset=UTF-8'
            }}).success(function(result){ 
            console.log(result) 
                $timeout(function(){
                  alertLoader.close();
                  if (result[0] == 'ERROR') {
                    var alertIncorrecto = $ionicPopup.alert({
                      title : 'Error . .',
                      template : 'Usuario y/o contraseña incorrectas.'
                    })
                  }else{
                    console.log(result[0]);
                    if (result[0].tipo_usuario == "SUP") {
                      localStorage.setItem('dataSuper',JSON.stringify(result));
                      $state.go('tab.dash');
                    }else{
                      localStorage.setItem('dataSuper',JSON.stringify(result));
                      $state.go('tab.dash');
                    }
                  }   
                },1100)
            }).error(function(err){
               $ionicPopup.alert({
                  title : 'Error . .',
                  template : 'Ocurrio un problema con la conexión..'
                })
            })
  }
   $ionicModal.fromTemplateUrl('usuarionew.html', {
    scope: $scope,
    animation: 'slide-in-up'
   }).then(function(modal) {
    $scope.modal = modal;
   });

  $scope.openModal = function() {

    $scope.modal.show();
  };
  $scope.closeModal = function() {
    console.log('Close')
    $scope.modal.hide();
  };
    $scope.paramsUser = {
      nombres : '',
      apellidos : '',
      dni : '',
      edad : '',
      direccion : '',
      usuario : '',
      pass : '',
    }  
  $scope.newUsusario = function(){

    var url = urlApi + 'newUsuario.php';    
    $http.post(url,$scope.paramsUser,{
              headers : {
                'Content-Type' : 'application/x-www-form-urlencoded; charset=UTF-8'
            }}).success(function(result){ 
              var alertMo =  $ionicPopup.alert({
                  title : 'Felicidades . .',
                  template : 'Usuario creado correctamente'
                })   
              alertMo.then(function(res){
                $scope.closeModal();
    $scope.paramsUser = {
      nombres : '',
      apellidos : '',
      dni : '',
      edad : '',
      direccion : '',
      usuario : '',
      pass : '',
    }                  
              })
            }).error(function(err){
               $ionicPopup.alert({
                  title : 'Error . .',
                  template : 'Ocurrio un problema con la conexión..'
                })
            })    
  }   
})
.controller('ChatsCtrl', function($scope, Chats , $ionicPopup,$http,$state) {
    var dataSuper = JSON.parse(localStorage.getItem('dataSuper'))[0];
    
    $scope.getHistorial = function(){
     var url = urlApi + 'listHistorial.php';
    var params = {
      pesona : dataSuper.ID_PERSONA
    }
    console.log(params)
    $http.post(url,params,{
              headers : {
                'Content-Type' : 'application/x-www-form-urlencoded; charset=UTF-8'
            }}).success(function(result){
              if (result[0] == "ERROR") {return;};
              $scope.listViajes = result;
            }).error(function(err){
               $ionicPopup.alert({
                  title : 'Error . .',
                  template : 'Ocurrio un problema con la conexión..'
                })
            })     
    }
    $scope.verDetalle = function(item){
      console.log(item)
      $state.go('tab.chat-detail',{ chatId : item.ASIENTOS_SELECCIONADOS + '|' + item.ID_RESERVAS + '|' + item.puntaje});
    }
})

.controller('ChatDetailCtrl', function($scope, $stateParams, Chats,$ionicPopup,$http,$ionicModal) {
    var parameters = $stateParams.chatId.split('|');
    var asientos = parameters[0];
    var id_reserva = parameters[1];
    $scope.point = parameters[2];    
    $scope.getColorStar=function(valor){    
     if (valor<=$scope.point) {
      return 'color:#EF473A;'
     }; 
    $scope.setPointStar=function(valor){
      $scope.point=valor;
      changedPoint(valor);
    }
    var changedPoint = function(){
      var params = {
        id_reserva : id_reserva,
        puntaje : $scope.point
      }
    var url = urlApi + 'savePuntaje.php';    
    $http.post(url,params,{
              headers : {
                'Content-Type' : 'application/x-www-form-urlencoded; charset=UTF-8'
            }}).success(function(result){ 
              console.log(result)
            }).error(function(err){
               $ionicPopup.alert({
                  title : 'Error . .',
                  template : 'Ocurrio un problema con la conexión..'
                })
            })
    }
    }


   $scope.initListaAsientos = function(){
   $scope.listAsientos = [{
      piso : 1 ,des : 'Primer piso', content : [ {row : 1, asientos : [
        {id : 1, estatus : 1},{id : 2, estatus : 1},{id : 0},{id : 0},{id : 3, estatus : 1}
        ]},  
      {row : 1, asientos : [
        {id : 4, estatus : 1},{id : 5, estatus : 1},{id : 0},{id : 0},{id : 6, estatus : 1}
        ]},     
      {row : 1, asientos : [
        {id : 7, estatus : 1},{id : 8, estatus : 1},{id : 0},{id : 0},{id : 9, estatus : 1}
        ]},
      {row : 1, asientos : [
        {id : 10, estatus : 1},{id : 11, estatus : 1},{id : 0},{id : 0},{id : 12, estatus : 1}
        ]}]
     },  
     {piso : 2 ,des : 'Segundo piso' ,content : [
     {row : 1, asientos : [
        {id : 13, estatus : 1},{id : 14, estatus : 1},{id : 0},{id : 15, estatus : 1},{id : 16, estatus : 1}
        ]},
     {row : 1, asientos : [
        {id : 17, estatus : 1},{id : 18, estatus : 1},{id : 0},{id : 0},{id : 0}
        ]},         
      {row : 1, asientos : [
        {id : 19, estatus : 1},{id : 20, estatus : 1},{id : 0},{id : 0},{id : 0}
        ]},
     {row : 1, asientos : [
        {id : 21, estatus : 1},{id : 22, estatus : 1},{id : 0},{id : 23, estatus : 1},{id : 24, estatus : 1}
        ]},
     {row : 1, asientos : [
        {id : 25, estatus : 1},{id : 26, estatus : 1},{id : 0},{id : 27, estatus : 1},{id : 28, estatus : 1}
        ]},
           {row : 1, asientos : [
        {id : 29, estatus : 1},{id : 30, estatus : 1},{id : 0},{id : 31, estatus : 1},{id : 32, estatus : 1}
        ]},
           {row : 1, asientos : [
        {id : 33, estatus : 1},{id : 34, estatus : 1},{id : 0},{id : 35, estatus : 1},{id : 36, estatus : 1}
        ]},
           {row : 1, asientos : [
        {id : 37, estatus : 1},{id : 38, estatus : 1},{id : 0},{id : 39, estatus : 1},{id : 40, estatus : 1}
        ]},
           {row : 1, asientos : [
        {id : 41, estatus : 1},{id : 42, estatus : 1},{id : 0},{id : 43, estatus : 1},{id : 44, estatus : 1}
        ]},      ]}
     ]

      asientos = JSON.parse(asientos);
      $scope.listAsientos.forEach(function(item1,index){        
         item1.content.forEach(function(item2,index){
           item2.asientos.forEach(function(item3,index){
             if (asientos.includes(item3.id)) {
               item3.estatus = 0;
             };
           })
         })
      })

   }    
})

.controller('AccountCtrl', function($scope) {
  $scope.settings = {
    enableFriends: true
  };
})

.controller('newCheckCtrl', function($scope,$ionicPopup,$timeout,$http,$cordovaGeolocation,$q,$state){

  $scope.paramsReserva = {
    origen : '(Seleccionar Aqui)',
    destino : '(Seleccionar Aqui)',
    salida : '(Seleccionar Aqui)',
    idOrigen : '',
    idDestino : '',
    idtipo : '',
    fechaP : '',
    fechaR : '',
  }
  $scope.getCiudades = function(){
    var url = urlApi + 'listCiudades.php';    
    $http.get(url,{
              headers : {
             'Content-Type' : 'application/x-www-form-urlencoded; charset=UTF-8'
            }}).success(function(result){  
            console.log(result)            
              $scope.listCiudades = result;
            })  
            .error(function(err){
              console.log(err)
            }) 
  }
  $scope.getCiudades();
  $scope.modalSalidas = function(){

    $scope.listSalidas = [
      {id : 1, des: 'Ida'},
      {id : 2, des: 'Ida / Retorno'},
    ]
    var cabecera = "Seleccionar una Ejecutada";
    var template = '<div class="modalStyle">' +
             '<div class="card-panel grey lighten-5 z-depth-1 cardP" ng-repeat="item in listSalidas">' +
                   '<div class="row valign-wrapper contentPlantilla" ng-click="selectIdSalidas(item);">'+
                   '<div class="col s8 m10"><span class="black-text">{{item.des}}</span>' +
                   '</div></div></div></div>';
    alertPopup = $ionicPopup.alert({
      title: cabecera,
      template: template,
      cssClass: '',
      scope:$scope
    });    
  }
  var alertPopup;
  $scope.modalSelect = function(tipo){
    var cabecera = "Seleccionar una Ejecutada";
    var template = '<div class="modalStyle"> <label class="item item-input search">'+
                    '<i class="icon ion-search placeholder-icon"></i>' +
                    '<input type="text" placeholder="Busqueda . ." ng-model="search"></label>' +
             '<div class="card-panel grey lighten-5 z-depth-1 cardP" ng-repeat="item in listCiudades | filter : search">' +
                   '<div class="row valign-wrapper contentPlantilla" ng-click="selectId(item,'+ tipo +');">'+
                   '<div class="col s8 m10"><span class="black-text">{{item.NOMBRE_CIUDAD}}</span>' +
                   '</div></div></div></div>';
    alertPopup = $ionicPopup.alert({
      title: cabecera,
      template: template,
      cssClass: '',
      scope:$scope
    });
  }
  $scope.selectId = function(item,tipo){
    if (tipo == 1) {
      $scope.paramsReserva.idOrigen = item.ID_CIUDAD;
      $scope.paramsReserva.origen = item.NOMBRE_CIUDAD;
    }else{
      $scope.paramsReserva.idDestino = item.ID_CIUDAD;
      $scope.paramsReserva.destino = item.NOMBRE_CIUDAD;
    }
    alertPopup.close();
  }
  $scope.selectIdSalidas = function(item){
    if (item.id== 1) {
      $scope.showRetorno = false;
    }else{
      $scope.showRetorno = true;
    }
    $scope.paramsReserva.idtipo = item.id;
    $scope.paramsReserva.salida = item.des;
    alertPopup.close();
  }
  $scope.buscar = function(){
    var template = "<div style='text-align:center;'>" +
                       "<ion-spinner icon='android' class='loadingok'></ion-spinner></div>";    
    var alertLoader = $ionicPopup.alert({
                title : 'Buscando Destinos. .',
                template : template,
                cssClass : 'popButtonHide',
                scope: $scope          
              })      
    $scope.paramsReserva.fechaP = document.getElementById('dtFecha').value;
    $scope.paramsReserva.fechaR = document.getElementById('dtFechaR').value;
    console.log($scope.paramsReserva)
    var url = urlApi + 'listViajes.php';    
    $http.post(url,$scope.paramsReserva,{
              headers : {
             'Content-Type' : 'application/x-www-form-urlencoded; charset=UTF-8'
            }}).success(function(result){
              console.log(result)
              if (result[0] == "ERROR") { $scope.listViajes = []; alertLoader.close(); return;}
              $timeout(function(){
                alertLoader.close();
                $scope.listViajes = result;
              },1200)              
            })  
            .error(function(err){
              console.log(err)
            })    
  }

  $scope.addViaje = function(item){
    localStorage.setItem('dataDestino', JSON.stringify(item));
    $state.go('tab.datosgenerales');
  }
})
.controller('datosCtrl', function($scope,$state){
   var dataSuper = JSON.parse(localStorage.getItem('dataSuper'))[0];
   var dataDestino = JSON.parse(localStorage.getItem('dataDestino'));

   $scope.params = {
      origen : dataDestino.origen,
      destino : dataDestino.destino,
      dni : dataSuper.DNI,
      apellidos : dataSuper.APELLIDOS_PERSONA,
      nombres : dataSuper.NOMBRE_PERSONA
   }
   $scope.goToAsientos = function(){
    $state.go('tab.asientos')
   }
})
.controller('asientosCtrl',function($scope,$ionicPopup,$http,$timeout,$state,$ionicModal){
  var dataSuper = JSON.parse(localStorage.getItem('dataSuper'))[0];
   var dataDestino = JSON.parse(localStorage.getItem('dataDestino'));
   var precioReal = dataDestino.PRECIO_VIAJES;   
   //$scope.precioTotal = parseFloat(dataDestino.PRECIO_VIAJES);
   $scope.precioTotal = 0.0;
   $scope.initListaAsientos = function(){
   $scope.listAsientos = [{
      piso : 1 ,des : 'Primer piso', content : [ {row : 1, asientos : [
        {id : 1, estatus : 1},{id : 2, estatus : 1},{id : 0},{id : 0},{id : 3, estatus : 1}
        ]},  
      {row : 1, asientos : [
        {id : 4, estatus : 1},{id : 5, estatus : 1},{id : 0},{id : 0},{id : 6, estatus : 1}
        ]},     
      {row : 1, asientos : [
        {id : 7, estatus : 1},{id : 8, estatus : 1},{id : 0},{id : 0},{id : 9, estatus : 1}
        ]},
      {row : 1, asientos : [
        {id : 10, estatus : 1},{id : 11, estatus : 1},{id : 0},{id : 0},{id : 12, estatus : 1}
        ]}]
     },  
     {piso : 2 ,des : 'Segundo piso' ,content : [
     {row : 1, asientos : [
        {id : 13, estatus : 1},{id : 14, estatus : 1},{id : 0},{id : 15, estatus : 1},{id : 16, estatus : 1}
        ]},
     {row : 1, asientos : [
        {id : 17, estatus : 1},{id : 18, estatus : 1},{id : 0},{id : 0},{id : 0}
        ]},         
      {row : 1, asientos : [
        {id : 19, estatus : 1},{id : 20, estatus : 1},{id : 0},{id : 0},{id : 0}
        ]},
     {row : 1, asientos : [
        {id : 21, estatus : 1},{id : 22, estatus : 1},{id : 0},{id : 23, estatus : 1},{id : 24, estatus : 1}
        ]},
     {row : 1, asientos : [
        {id : 25, estatus : 1},{id : 26, estatus : 1},{id : 0},{id : 27, estatus : 1},{id : 28, estatus : 1}
        ]},
           {row : 1, asientos : [
        {id : 29, estatus : 1},{id : 30, estatus : 1},{id : 0},{id : 31, estatus : 1},{id : 32, estatus : 1}
        ]},
           {row : 1, asientos : [
        {id : 33, estatus : 1},{id : 34, estatus : 1},{id : 0},{id : 35, estatus : 1},{id : 36, estatus : 1}
        ]},
           {row : 1, asientos : [
        {id : 37, estatus : 1},{id : 38, estatus : 1},{id : 0},{id : 39, estatus : 1},{id : 40, estatus : 1}
        ]},
           {row : 1, asientos : [
        {id : 41, estatus : 1},{id : 42, estatus : 1},{id : 0},{id : 43, estatus : 1},{id : 44, estatus : 1}
        ]},      ]}
     ]     
     if (dataDestino.ASIENTOS_RESERVADOS !="") {
       var asientosReservados = JSON.parse(dataDestino.ASIENTOS_RESERVADOS);
       $scope.listAsientos.forEach(function(item1,index){        
          item1.content.forEach(function(item2,index){
            item2.asientos.forEach(function(item3,index){
              if (asientosReservados.includes(item3.id)) {
                item3.estatus = 0;
              };
            })
          })
       })      
     };

   }
  $scope.modalNew;
   $ionicModal.fromTemplateUrl('usuarionew.html', {
    scope: $scope,
    animation: 'slide-in-up'
   }).then(function(modal) {
    $scope.modalNew = modal;
   });
  $scope.openModal = function() {

    $scope.modalNew.show();
  };
  $scope.closeModal = function() {
    console.log('Close')
    $scope.modalNew.hide();
  };    
    $scope.newPersonaAsiento = function(){
      $scope.closeModal();
    }   

   var asientosSeleccionados = [];
   $scope.selectAsiento = function(piso,itemAsiento){
    if (itemAsiento.estatus == 0) {
      return;
    };
    var template = "";
    var listaAsientos;
    if (piso == 1) {
      listaAsientos = $scope.listAsientos[0];
      template = "Esta por seleccionar un asiento del primer piso , tendra un costo de 20 S/. adicionales , desea continuar ?";
    }else{
      template = "Esta por seleccionar un asiento del segundo piso, no tendra ningun costo adicional, desea continuar ?"
      listaAsientos = $scope.listAsientos[1];
    }

    var alertPopup = $ionicPopup.confirm({
       title: 'Confirmar..',
       template: template,
       cssClass: 'checkPop',
       scope:$scope
     });
    alertPopup.then(function(res){
      if (res) {
        
        listaAsientos.content.forEach(function(item,index){
          item.asientos.forEach(function(items,index){            
            if (items.id == itemAsiento.id) {
              items.estatus = 0;
              asientosSeleccionados.push(items.id);
              if (asientosSeleccionados.length > 1) {
                $scope.openModal();
              }              
              
              if (piso == 1) {
                $scope.precioTotal += parseFloat(precioReal) + 20;
              }else{
                $scope.precioTotal += parseFloat(precioReal);
              };
            };
          })
        })
      };
    })
   }
   $scope.goToPago = function(){
    var template = "<div style='text-align:center;'>" +
                           "<ion-spinner icon='android' class='loadingok'></ion-spinner></div>";    
        var alertLoader = $ionicPopup.alert({
                    title : 'Reservando Asientos . .',
                    template : template,
                    cssClass : 'popButtonHide',
                    scope: $scope          
     })
    var url = urlApi + 'saveAsientoReservado.php';
    localStorage.setItem('asientosSelect',JSON.stringify(asientosSeleccionados));    
    
    if (dataDestino.ASIENTOS_RESERVADOS !="") {
      var asientosRE = JSON.parse(dataDestino.ASIENTOS_RESERVADOS)
      dataDestino.PRECIO_VIAJES = $scope.precioTotal;
      asientosRE.forEach(function(item){
        asientosSeleccionados.push(item);
      })      
    };

    var params = {
      id_destino : dataDestino.ID_DESTINO,
      asientos : JSON.stringify(asientosSeleccionados)
    }
    console.log(params)
    $http.post(url,params,{
              headers : {
             'Content-Type' : 'application/x-www-form-urlencoded; charset=UTF-8'
            }}).success(function(result){
              dataDestino.PRECIO_VIAJES = $scope.precioTotal;
              dataDestino.ASIENTOS_RESERVADOS = JSON.stringify(asientosSeleccionados);
              localStorage.setItem('dataDestino',JSON.stringify(dataDestino));
              $timeout(function(){                
                alertLoader.close();
                $state.go('tab.pago');
              },1200)
            })  
            .error(function(err){
              console.log(err)
            })      
   }

})
.controller('pagosCtrl',function($scope,$http,$ionicPopup,$timeout,$state){
    var dataSuper = JSON.parse(localStorage.getItem('dataSuper'))[0];    
   var dataDestino = JSON.parse(localStorage.getItem('dataDestino'));   
   var dataAsientos = JSON.parse(localStorage.getItem('asientosSelect'))
   
  $scope.tipoPago = {
    presencial : true,
    tarjeta : false
  }
  $scope.changeTipoPago = function(tipo){
    if (tipo == 1) {
      $scope.tipoPago.presencial = true;
      $scope.tipoPago.tarjeta = false;
      
    }else{
      $scope.tipoPago.presencial = false;
      $scope.tipoPago.tarjeta = true;
      
    };
    
  }
  var alertPopup;
    $scope.selectFecha = function(tipo){
      if (tipo == 1) {
        $scope.listFechas = ['01','02','03','04','05','06','07','08','09','10','11','12'];
      }else{
        $scope.listFechas = ['2017','2018','2019','2020','2021','2022','2023','2024','2025','2026','2027']
      };
    var cabecera = "Seleccionar una Ejecutada";
    var template = '<div class="modalStyle"> <label class="item item-input search">'+
                    '<i class="icon ion-search placeholder-icon"></i>' +
                    '<input type="text" placeholder="Busqueda . ." ng-model="search"></label>' +
             '<div class="card-panel grey lighten-5 z-depth-1 cardP" ng-repeat="item in listFechas | filter : search">' +
                   '<div class="row valign-wrapper contentPlantilla" ng-click="selectId(item,'+ tipo +');">'+
                   '<div class="col s8 m10"><span class="black-text">{{item}}</span>' +
                   '</div></div></div></div>';
    alertPopup = $ionicPopup.alert({
      title: cabecera,
      template: template,
      cssClass: '',
      scope:$scope
    });
  }
  $scope.fecha = {
    dia : '01',
    anio : '2017',
  }
  $scope.selectId = function(item,tipo){
    
    if (tipo == 1) {
      $scope.fecha.dia = item;
    }else{
      $scope.fecha.anio = item;
    };
    alertPopup.close();
  }
  $scope.generarReserva = function(){
    var alertPopup = $ionicPopup.confirm({
       title: 'Confirmar..',
       template: 'Esta apunto de generar una reserva, desea continuar ?',
       cssClass: 'checkPop',
       scope:$scope
     });
    alertPopup.then(function(res){
      if (res) {
       var template = "<div style='text-align:center;'>" +
                           "<ion-spinner icon='android' class='loadingok'></ion-spinner></div>";    
        var alertLoader = $ionicPopup.alert({
                    title : 'Generando reserva . .',
                    template : template,
                    cssClass : 'popButtonHide',
                    scope: $scope          
        })     
        var url = urlApi + 'saveReserva.php';
        console.log(url)
        var estadoR = $scope.tipoPago.presencial == true ? '1' : '2';        
        var params = {
          ID_USUARIO : dataSuper.ID_USUARIO,
          ID_DESTINO : dataDestino.ID_DESTINO,
          FECHA_RESERVA : getFecha(),
          HORA_RESERVA : getHora(),
          ID_PERSONA : dataSuper.ID_PERSONA,
          CANTIDAD : dataAsientos.length,
          PRECIO_TOTAL : String(dataDestino.PRECIO_VIAJES) + '.00',
          ESTADO_RESERVA : estadoR,
          ASIENTOS_RESERVADOS: JSON.stringify(dataAsientos)
        }
        console.log(params)
        $http.post(url,params,{
              headers : {
             'Content-Type' : 'application/x-www-form-urlencoded; charset=UTF-8'
            }}).success(function(result){
              console.log(result)
              $timeout(function(){
                alertPopup.close();                
                alertLoader.close();
                  var alertCongrat = $ionicPopup.alert({
                      title : 'Felicidades . .',
                      template : 'Reserva realizada correctamente !'
                    })
                  alertCongrat.then(function(){
                    $state.go('tab.chats');    
                  })
                
              },1200)
            })  
            .error(function(err){
              console.log(err)
            })           

      };
    })
  }

})
.controller('CiudadesCtrl',function($scope,$http,$ionicModal){

  $scope.getCiudades = function(){
    var url = urlApi + 'listCiudades.php';    
    $http.get(url,{
              headers : {
             'Content-Type' : 'application/x-www-form-urlencoded; charset=UTF-8'
            }}).success(function(result){  
            console.log(result)            
              $scope.listCiudades = result;
            })  
            .error(function(err){
              console.log(err)
            }) 
  }
   $ionicModal.fromTemplateUrl('my-modal.html', {
    scope: $scope,
    animation: 'slide-in-up'
   }).then(function(modal) {
    $scope.modal = modal;
   });
  $scope.openModal = function(item) {    
    var ubi = item.ubicacion.split('|');
    $scope.ubicacion = {
      lat : ubi[0],
      long : ubi[1]
    }
    $scope.modal.show();
  };
  $scope.closeModal = function() {
    console.log('Close')
    $scope.modal.hide();
  };     
})