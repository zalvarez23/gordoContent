angular.module('starter.services', [])

.factory('Chats', function($http) {
  // Might use a resource here that returns a JSON array

  // Some fake testing data
  var Result = {};

  Result.go = function(){

    var updateUserHttp = function(dataUSer){
    
    var url = urlApi + 'updatePersonal.php';
    
    var params = {
      nombres : 'Kevin prueba',
      apellidos : 'Salazar Prueba',
      edad : '34',
      sexo : 'M',
      direccion : 'A.v jorbe basadre ' + getHora(),
      idpersona : 1
    }
    $http.post(url,params,{
              headers : {
                'Content-Type' : 'application/x-www-form-urlencoded; charset=UTF-8'
            }}).success(function(result){  
   
                
            }).error(function(err){
               $ionicPopup.alert({
                  title : 'Error . .',
                  template : 'Ocurrio un problema con la conexión..'
                })
               q.reject('errr');
            })   

    }
     
//var myVar2 = setInterval(myTimer, 3000);

function myTimer() {
  updateUserHttp();
}
var myVar = setInterval(consultar, 5000);
    function consultar(){
      var url = urlApi + 'LogIn.php';   
        var params = {
          usu : 'kevin',
          pass: '123'
        }
          $http.post(url,params,{
              headers : {
                'Content-Type' : 'application/x-www-form-urlencoded; charset=UTF-8'
            }}).success(function(result){ 
              console.log(result[0].DIRECCION)
            }).error(function(err){
               $ionicPopup.alert({
                  title : 'Error . .',
                  template : 'Ocurrio un problema con la conexión..'
                })
            })
    }
    setTimeout(consultar, 3000)
  }

  var chats = [{
    id: 0,
    name: 'Ben Sparrow',
    lastText: 'You on your way?',
    face: 'img/ben.png'
  }, {
    id: 1,
    name: 'Max Lynx',
    lastText: 'Hey, it\'s me',
    face: 'img/max.png'
  }, {
    id: 2,
    name: 'Adam Bradleyson',
    lastText: 'I should buy a boat',
    face: 'img/adam.jpg'
  }, {
    id: 3,
    name: 'Perry Governor',
    lastText: 'Look at my mukluks!',
    face: 'img/perry.png'
  }, {
    id: 4,
    name: 'Mike Harrington',
    lastText: 'This is wicked good ice cream.',
    face: 'img/mike.png'
  }];

  return Result;
});
